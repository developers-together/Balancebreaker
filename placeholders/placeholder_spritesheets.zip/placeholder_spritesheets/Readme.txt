1. This stuff is free. Use it without credit, as it's just a placeholder.
2. If you DO decide to make this your game's art style, credit me as "Lim95 - Artist" or "Art from lim95.itch.io"

GDEVELOP SPRITESHEETS
1. Import into the built-in Piskel editor.
2. Choose "import as spritesheet"
3. Set the frame size to the end of the filename (8x8, 32x32, 128x128, ect)
4. Save it and you're done!